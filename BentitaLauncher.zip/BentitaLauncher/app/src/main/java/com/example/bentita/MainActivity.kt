@file:OptIn(ExperimentalFoundationApi::class)
package com.example.bentita

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        setContent { Launcher(this) }
    }
}

data class App(val label: String, val pkg: String)

@Composable fun Bg() = Box(Modifier.fillMaxSize().background(
    Brush.verticalGradient(listOf(Color(0xFF1F5F7F), Color(0xFF3A1B4A), Color(0xFF06080D)))))

// Bentita: copie blurata a fundalului, decupata exact in dreptul ei, plus un strat alb translucid.
@Composable fun Band(label: String, s: Float, onClick: () -> Unit, onLong: () -> Unit, modifier: Modifier = Modifier) {
    var pos by remember { mutableStateOf(Offset.Zero) }
    val cfg = LocalConfiguration.current
    Box(modifier.fillMaxWidth()
        .clip(RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp))
        .onGloballyPositioned { pos = it.positionInRoot() }
        .combinedClickable(onClick = onClick, onLongClick = onLong)) {
        Box(Modifier.wrapContentSize(Alignment.TopStart, unbounded = true)
            .requiredSize(cfg.screenWidthDp.dp, cfg.screenHeightDp.dp)
            .offset { IntOffset(-pos.x.roundToInt(), -pos.y.roundToInt()) }
            .blur(24.dp)) { Bg() }
        Box(Modifier.matchParentSize().background(Color.White.copy(alpha = .14f)))
        Text(label, color = Color.White, fontSize = (26 * s).sp, fontWeight = FontWeight.Light,
            modifier = Modifier.padding(horizontal = 28.dp, vertical = (12 * s).dp))
    }
}

@Composable fun Text(t: String, color: Color, fontSize: TextUnit, modifier: Modifier = Modifier, fontWeight: FontWeight? = null) =
    androidx.compose.foundation.text.BasicText(t, modifier, TextStyle(color = color, fontSize = fontSize, fontWeight = fontWeight))

@Composable fun Launcher(ctx: Context) {
    val pm = ctx.packageManager
    val prefs = remember { ctx.getSharedPreferences("l", 0) }
    val apps = remember {
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
    var favs by remember { mutableStateOf(prefs.getString("f", "")!!.split(",").filter { it.isNotEmpty() }) }
    fun setFavs(l: List<String>) { favs = l; prefs.edit().putString("f", l.joinToString(",")).apply() }
    fun toggle(p: String) = setFavs(if (p in favs) favs - p else favs + p)
    fun open(p: String) { pm.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } }
    var drawer by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val time by produceState("") { while (true) { value = SimpleDateFormat("HH:mm").format(Date()); delay(15000) } }
    BackHandler(drawer) { drawer = false; q = "" }

    Box(Modifier.fillMaxSize()) {
        Bg()
        Column(Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(Unit) { detectVerticalDragGestures { _, d -> if (d < -25f) drawer = true } }) {
            Text(time, Color.White, 76.sp, Modifier.padding(28.dp, 40.dp, 0.dp, 0.dp), FontWeight.ExtraLight)
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomStart) {
                val s = (6.5f / favs.size.coerceAtLeast(1)).coerceIn(.4f, 1f)   // cu cat mai multe, cu atat mai mici
                Column(Modifier.verticalScroll(rememberScrollState()).padding(end = 56.dp)) {
                    favs.mapNotNull { p -> apps.find { it.pkg == p } }.forEach { a ->
                        Band(a.label, s, { open(a.pkg) }, { toggle(a.pkg) }, Modifier.padding(bottom = (10 * s).dp))
                    }
                }
            }
            Text("Toate aplicatiile  ↑", Color(0x99FFFFFF), 14.sp,
                Modifier.padding(28.dp).clickable { drawer = true })
        }
        AnimatedVisibility(drawer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            Box(Modifier.fillMaxSize()) {
                Bg(); Box(Modifier.fillMaxSize().background(Color(0x99000000)))
                Column(Modifier.fillMaxSize().systemBarsPadding()) {
                    Box(Modifier.padding(20.dp).fillMaxWidth().clip(CircleShape)
                        .background(Color(0x22FFFFFF)).padding(18.dp, 12.dp)) {
                        if (q.isEmpty()) Text("Cauta aplicatii", Color(0x99FFFFFF), 16.sp)
                        BasicTextField(q, { q = it }, textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(Color.White), singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    LazyColumn(Modifier.weight(1f).padding(end = 16.dp)) {
                        items(apps.filter { it.label.contains(q, true) }, key = { it.pkg }) { a ->
                            Row(Modifier.padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Band(a.label, .85f, { open(a.pkg) }, { toggle(a.pkg) }, Modifier.weight(1f))
                                Text(if (a.pkg in favs) "✓" else "+", Color.White, 26.sp,
                                    Modifier.padding(start = 14.dp).clickable { toggle(a.pkg) })
                            }
                        }
                    }
                }
            }
        }
    }
}
